{{-- Atom Framework Search Element - Tailwind --}}
<div class="atom-search max-w-md">
    <flux:input 
        type="search"
        placeholder="{{ $placeholder ?? 'Search...' }}"
        wire:model.live.debounce.300ms="tableSearch"
        class="w-full"
    >
        <flux:icon name="magnifying-glass" class="w-4 h-4 text-gray-400" slot="leading" />
        @if(!empty($tableSearch))
            <button 
                wire:click="$set('tableSearch', '')" 
                class="p-1 text-gray-400 hover:text-gray-600"
                slot="trailing"
            >
                <flux:icon name="x-mark" class="w-4 h-4" />
            </button>
        @endif
    </flux:input>
</div>