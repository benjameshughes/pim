{{-- Atom Framework Stats Element - Tailwind --}}
<div class="atom-stats grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
    <div class="stat-card bg-white rounded-lg border p-6 dark:bg-gray-800 dark:border-gray-700">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-sm text-gray-500 dark:text-gray-400">Total</p>
                <p class="text-2xl font-semibold text-gray-900 dark:text-white">{{ number_format($total ?? 0) }}</p>
            </div>
            <flux:icon name="cube" class="w-8 h-8 text-blue-500" />
        </div>
    </div>
    
    <div class="stat-card bg-white rounded-lg border p-6 dark:bg-gray-800 dark:border-gray-700">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-sm text-gray-500 dark:text-gray-400">This Month</p>
                <p class="text-2xl font-semibold text-gray-900 dark:text-white">{{ number_format($thisMonth ?? 0) }}</p>
            </div>
            <flux:icon name="calendar" class="w-8 h-8 text-green-500" />
        </div>
    </div>
    
    <div class="stat-card bg-white rounded-lg border p-6 dark:bg-gray-800 dark:border-gray-700">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-sm text-gray-500 dark:text-gray-400">Today</p>
                <p class="text-2xl font-semibold text-gray-900 dark:text-white">{{ number_format($todayCount ?? 0) }}</p>
            </div>
            <flux:icon name="clock" class="w-8 h-8 text-orange-500" />
        </div>
    </div>
</div>