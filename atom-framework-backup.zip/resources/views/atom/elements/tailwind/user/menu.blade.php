{{-- Atom Framework User Menu Element - Tailwind --}}
@if($user)
    <div class="atom-user-menu relative">
        <flux:dropdown>
            <flux:button variant="ghost" size="sm">
                <div class="flex items-center gap-2">
                    @if($user->avatar ?? false)
                        <img src="{{ $user->avatar }}" alt="{{ $user->name }}" class="w-6 h-6 rounded-full">
                    @else
                        <flux:icon name="user-circle" class="w-6 h-6" />
                    @endif
                    <span class="hidden md:block">{{ $user->name }}</span>
                    <flux:icon name="chevron-down" class="w-4 h-4" />
                </div>
            </flux:button>
            
            <flux:menu>
                @if(isset($profileRoute))
                    <flux:menu.item href="{{ $profileRoute }}" wire:navigate>
                        <flux:icon name="user" class="w-4 h-4" />
                        Profile
                    </flux:menu.item>
                @endif
                
                <flux:menu.item href="/settings" wire:navigate>
                    <flux:icon name="cog-6-tooth" class="w-4 h-4" />
                    Settings
                </flux:menu.item>
                
                <flux:menu.separator />
                
                <flux:menu.item href="{{ $logoutRoute ?? route('logout') }}" method="post">
                    <flux:icon name="arrow-right-on-rectangle" class="w-4 h-4" />
                    Sign out
                </flux:menu.item>
            </flux:menu>
        </flux:dropdown>
    </div>
@endif