{{-- Atom Framework Breadcrumbs Element - Tailwind --}}
@if(!empty($breadcrumbs))
    <nav class="atom-breadcrumbs mb-4">
        <ol class="flex items-center space-x-2 text-sm text-gray-500">
            @foreach($breadcrumbs as $breadcrumb)
                @if(!$loop->last)
                    <li>
                        <a href="{{ $breadcrumb['url'] }}" class="hover:text-gray-700 transition-colors" wire:navigate>
                            {{ $breadcrumb['label'] }}
                        </a>
                        <span class="mx-2 text-gray-400">/</span>
                    </li>
                @else
                    <li class="text-gray-900 font-medium">{{ $breadcrumb['label'] }}</li>
                @endif
            @endforeach
        </ol>
    </nav>
@endif