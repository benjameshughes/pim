{{-- Atom Framework Sub-Navigation Element - Tailwind --}}
@if(!empty($items))
    <div class="atom-sub-navigation mt-6">
        <div class="border-b border-gray-200 dark:border-gray-700">
            <nav class="-mb-px flex space-x-8">
                @foreach($items as $item)
                    <a 
                        href="{{ $item['url'] }}" 
                        class="py-2 px-1 border-b-2 font-medium text-sm transition-colors
                            {{ $item['active'] ?? false 
                                ? 'border-blue-500 text-blue-600 dark:border-blue-400 dark:text-blue-400' 
                                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300' 
                            }}"
                        wire:navigate
                    >
                        {{ $item['label'] }}
                        @if(!empty($item['badge']))
                            <span class="ml-2 inline-block py-0.5 px-2 text-xs bg-gray-100 text-gray-800 rounded-full dark:bg-gray-800 dark:text-gray-200">
                                {{ $item['badge'] }}
                            </span>
                        @endif
                    </a>
                @endforeach
            </nav>
        </div>
    </div>
@endif