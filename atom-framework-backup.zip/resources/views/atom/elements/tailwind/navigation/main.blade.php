{{-- Atom Framework Navigation Element - Tailwind --}}
<nav class="atom-navigation">
    @if($items->isNotEmpty())
        <flux:navlist variant="outline">
            @foreach($items as $groupName => $group)
                @if($groupName === '_ungrouped')
                    {{-- Ungrouped items --}}
                    @foreach($group->getItems() as $item)
                        <flux:navlist.item 
                            icon="{{ $item->getIcon() ?? 'circle' }}" 
                            href="{{ $item->getUrl() }}" 
                            current="{{ $currentRoute === $item->getRoute() }}" 
                            wire:navigate
                        >
                            {{ $item->getLabel() }}
                        </flux:navlist.item>
                    @endforeach
                @else
                    {{-- Grouped items --}}
                    <flux:navlist.group expandable heading="{{ $groupName }}" icon="{{ $group->getIcon() ?? 'folder' }}">
                        @foreach($group->getItems() as $item)
                            <flux:navlist.item 
                                icon="{{ $item->getIcon() ?? 'circle' }}" 
                                href="{{ $item->getUrl() }}" 
                                current="{{ $currentRoute === $item->getRoute() }}" 
                                wire:navigate
                            >
                                {{ $item->getLabel() }}
                            </flux:navlist.item>
                        @endforeach
                    </flux:navlist.group>
                @endif
            @endforeach
        </flux:navlist>
    @else
        <div class="text-gray-500 text-sm p-4">No navigation items</div>
    @endif
</nav>