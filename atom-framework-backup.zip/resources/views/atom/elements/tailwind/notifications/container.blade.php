{{-- Atom Framework Notifications Element - Tailwind --}}
@if(!empty($notifications))
    <div class="atom-notifications fixed top-4 right-4 z-50 space-y-2 max-w-sm">
        @foreach($notifications as $notification)
            <div class="notification-toast bg-white border rounded-lg shadow-lg p-4 transform transition-all duration-300 
                {{ $notification['type'] === 'success' ? 'border-green-200 bg-green-50' : '' }}
                {{ $notification['type'] === 'error' ? 'border-red-200 bg-red-50' : '' }}
                {{ $notification['type'] === 'warning' ? 'border-yellow-200 bg-yellow-50' : '' }}
                {{ $notification['type'] === 'info' ? 'border-blue-200 bg-blue-50' : '' }}
            " 
            wire:key="notification-{{ $notification['id'] ?? $loop->index }}"
            x-data="{ show: true }" 
            x-show="show"
            x-transition:enter="transform ease-out duration-300 transition"
            x-transition:enter-start="translate-y-2 opacity-0 sm:translate-y-0 sm:translate-x-2"
            x-transition:enter-end="translate-y-0 opacity-100 sm:translate-x-0"
            x-transition:leave="transition ease-in duration-100"
            x-transition:leave-start="opacity-100"
            x-transition:leave-end="opacity-0">
                
                <div class="flex items-start">
                    <div class="flex-shrink-0">
                        @if($notification['type'] === 'success')
                            <flux:icon name="check-circle" class="w-5 h-5 text-green-500" />
                        @elseif($notification['type'] === 'error')
                            <flux:icon name="x-circle" class="w-5 h-5 text-red-500" />
                        @elseif($notification['type'] === 'warning')
                            <flux:icon name="exclamation-triangle" class="w-5 h-5 text-yellow-500" />
                        @else
                            <flux:icon name="information-circle" class="w-5 h-5 text-blue-500" />
                        @endif
                    </div>
                    
                    <div class="ml-3 flex-1">
                        @if(!empty($notification['title']))
                            <h4 class="text-sm font-medium text-gray-900">{{ $notification['title'] }}</h4>
                        @endif
                        @if(!empty($notification['message']))
                            <p class="mt-1 text-sm text-gray-600">{{ $notification['message'] }}</p>
                        @endif
                    </div>
                    
                    <div class="ml-4 flex-shrink-0 flex">
                        <button 
                            @click="show = false" 
                            class="inline-flex text-gray-400 hover:text-gray-600 focus:outline-none"
                        >
                            <flux:icon name="x-mark" class="w-4 h-4" />
                        </button>
                    </div>
                </div>
            </div>
        @endforeach
    </div>
@endif