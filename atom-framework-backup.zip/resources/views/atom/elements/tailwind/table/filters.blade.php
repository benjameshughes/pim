{{-- Atom Framework Table Filters Element - Tailwind --}}
@if(!empty($filters))
    <div class="atom-filters flex flex-wrap gap-2 mb-4">
        @foreach($filters as $filter)
            <div class="filter-item">
                <flux:select wire:model.live="tableFilters.{{ $filter['key'] ?? 'unknown' }}">
                    <flux:option value="">{{ $filter['label'] ?? 'Filter' }}</flux:option>
                    @if(!empty($filter['options']))
                        @foreach($filter['options'] as $value => $label)
                            <flux:option value="{{ $value }}">{{ $label }}</flux:option>
                        @endforeach
                    @endif
                </flux:select>
            </div>
        @endforeach
        
        @if(!empty($active) && array_filter($active))
            <flux:button 
                variant="subtle" 
                size="sm" 
                wire:click="resetTableFilters"
                class="text-gray-500 hover:text-gray-700"
            >
                <flux:icon name="x-mark" class="w-4 h-4 mr-1" />
                Clear filters
            </flux:button>
        @endif
    </div>
@endif