{{-- Atom Framework Pagination Element - Tailwind --}}
@if(isset($paginator) && $paginator->hasPages())
    <div class="atom-pagination mt-6">
        <div class="flex items-center justify-between">
            <div class="text-sm text-gray-500">
                Showing {{ $paginator->firstItem() }} to {{ $paginator->lastItem() }} of {{ $paginator->total() }} results
            </div>
            
            <div class="pagination-links">
                {{ $paginator->links() }}
            </div>
        </div>
        
        @if(!empty($perPageOptions))
            <div class="mt-4 flex items-center gap-2">
                <span class="text-sm text-gray-500">Show:</span>
                <flux:select wire:model.live="tableRecordsPerPage" class="w-20">
                    @foreach($perPageOptions as $option)
                        <flux:option value="{{ $option }}">{{ $option }}</flux:option>
                    @endforeach
                </flux:select>
                <span class="text-sm text-gray-500">per page</span>
            </div>
        @endif
    </div>
@endif