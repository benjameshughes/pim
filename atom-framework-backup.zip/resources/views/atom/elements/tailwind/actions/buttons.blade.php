{{-- Atom Framework Actions Element - Tailwind --}}
@if(!empty($actions))
    <div class="atom-actions flex gap-3">
        @foreach($actions as $action)
            <a 
                href="{{ $action['url'] ?? '#' }}"
                class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors inline-flex items-center"
                wire:navigate
            >
                @if(!empty($action['icon']))
                    <span class="mr-2">{{ $action['icon'] }}</span>
                @endif
                {{ $action['label'] }}
            </a>
        @endforeach
    </div>
@endif