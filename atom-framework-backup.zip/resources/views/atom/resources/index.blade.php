{{-- 
Atom Framework Resource Index View
This is the default view for resource index pages when using the LivewireResourceAdapter
--}}

<div class="resource-index">
    {{-- Page Header --}}
    <div class="mb-6">
        <h1 class="text-2xl font-bold text-gray-900">{{ $title }}</h1>
        
        @if(!empty($breadcrumbs))
            <nav class="mt-2">
                <ol class="flex items-center space-x-2 text-sm text-gray-500">
                    @foreach($breadcrumbs as $breadcrumb)
                        @if(!$loop->last)
                            <li>
                                <a href="{{ $breadcrumb['url'] }}" class="hover:text-gray-700">
                                    {{ $breadcrumb['label'] }}
                                </a>
                                <span class="mx-2">/</span>
                            </li>
                        @else
                            <li class="text-gray-900">{{ $breadcrumb['label'] }}</li>
                        @endif
                    @endforeach
                </ol>
            </nav>
        @endif
    </div>

    {{-- Actions --}}
    <div class="mb-6">
        {{ $this->actions }}
    </div>

    {{-- The Magic Table Property --}}
    <div class="bg-white rounded-lg shadow-sm border">
        {{ $this->table }}
    </div>

    {{-- Sub Navigation (if any) --}}
    @if(!empty($subNavigationItems))
        <div class="mt-6">
            <div class="border-b border-gray-200">
                <nav class="-mb-px flex space-x-8">
                    @foreach($subNavigationItems as $item)
                        <a 
                            href="{{ $item['url'] }}" 
                            class="py-2 px-1 border-b-2 {{ $item['active'] ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300' }} font-medium text-sm"
                        >
                            {{ $item['label'] }}
                            @if(!empty($item['badge']))
                                <span class="ml-2 inline-block py-0.5 px-2 text-xs bg-gray-100 text-gray-800 rounded-full">
                                    {{ $item['badge'] }}
                                </span>
                            @endif
                        </a>
                    @endforeach
                </nav>
            </div>
        </div>
    @endif
</div>