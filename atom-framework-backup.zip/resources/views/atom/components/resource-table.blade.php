<div class="resource-table">
    {{-- Search and Filters --}}
    @if($table->toArray()['searchable'] || $table->toArray()['filters'])
        <div class="table-controls mb-4 flex flex-col sm:flex-row gap-4">
            {{-- Search --}}
            @if($table->toArray()['searchable'])
                <div class="flex-1">
                    <input 
                        type="text" 
                        wire:model.live.debounce.300ms="tableSearch"
                        placeholder="Search {{ $config['pluralModelLabel'] }}..."
                        class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                </div>
            @endif
            
            {{-- Filters --}}
            @if($table->toArray()['filters'])
                <div class="flex gap-2">
                    @foreach($table->toArray()['filters'] as $filter)
                        <select wire:model.live="tableFilters.{{ $filter['key'] ?? 'unknown' }}" class="px-3 py-2 border border-gray-300 rounded-md">
                            <option value="">{{ $filter['label'] ?? 'Filter' }}</option>
                            {{-- Add filter options here based on filter type --}}
                        </select>
                    @endforeach
                </div>
            @endif
        </div>
    @endif

    {{-- Header Actions --}}
    @if($table->getHeaderActions())
        <div class="header-actions mb-4">
            @foreach($table->getHeaderActions() as $action)
                <button 
                    @if(method_exists($action, 'getUrl') && $action->getUrl())
                        onclick="window.location='{{ $action->getUrl() }}'"
                    @endif
                    class="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
                >
                    {{ $action->getLabel() }}
                </button>
            @endforeach
        </div>
    @endif

    {{-- Table --}}
    <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    {{-- Bulk selection column --}}
                    @if($table->getBulkActions())
                        <th class="px-6 py-3 text-left">
                            <input type="checkbox" wire:model.live="selectAll" class="rounded">
                        </th>
                    @endif
                    
                    {{-- Data columns --}}
                    @foreach($table->toArray()['columns'] as $column)
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            @if(($column['sortable'] ?? false))
                                <button wire:click="sortBy('{{ $column['key'] }}')">
                                    {{ $column['label'] }}
                                    @if($tableSortColumn === $column['key'])
                                        @if($tableSortDirection === 'asc')
                                            ↑
                                        @else
                                            ↓
                                        @endif
                                    @endif
                                </button>
                            @else
                                {{ $column['label'] }}
                            @endif
                        </th>
                    @endforeach
                    
                    {{-- Actions column --}}
                    @if($table->getActions())
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Actions
                        </th>
                    @endif
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
                @forelse($data as $record)
                    <tr>
                        {{-- Bulk selection --}}
                        @if($table->getBulkActions())
                            <td class="px-6 py-4">
                                <input type="checkbox" wire:model.live="selectedTableRecords" value="{{ $record->getKey() }}" class="rounded">
                            </td>
                        @endif
                        
                        {{-- Data cells --}}
                        @foreach($table->toArray()['columns'] as $column)
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                {{ $record->{$column['key']} }}
                            </td>
                        @endforeach
                        
                        {{-- Actions --}}
                        @if($table->getActions())
                            <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                @foreach($table->getActions() as $action)
                                    <button 
                                        wire:click="handleAction('{{ $action->getName() }}', '{{ $record->getKey() }}')"
                                        class="text-indigo-600 hover:text-indigo-900 mr-3"
                                    >
                                        {{ $action->getLabel() }}
                                    </button>
                                @endforeach
                            </td>
                        @endif
                    </tr>
                @empty
                    <tr>
                        <td colspan="100%" class="px-6 py-4 text-center text-gray-500">
                            {{ $table->toArray()['emptyStateHeading'] }}
                        </td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    {{-- Pagination --}}
    <div class="mt-4">
        {{ $data->links() }}
    </div>

    {{-- Bulk Actions --}}
    @if($table->getBulkActions() && !empty($selectedTableRecords))
        <div class="fixed bottom-4 left-1/2 transform -translate-x-1/2 bg-white shadow-lg rounded-lg p-4 border">
            <div class="flex items-center gap-4">
                <span class="text-sm text-gray-600">{{ count($selectedTableRecords) }} selected</span>
                @foreach($table->getBulkActions() as $action)
                    <button 
                        wire:click="handleBulkAction('{{ $action->getName() }}', selectedTableRecords)"
                        @if($action->requiresConfirmation())
                            onclick="return confirm('Are you sure?')"
                        @endif
                        class="px-3 py-2 bg-red-500 text-white text-sm rounded hover:bg-red-600"
                    >
                        {{ $action->getLabel() }}
                    </button>
                @endforeach
            </div>
        </div>
    @endif
</div>