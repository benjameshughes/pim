{{-- 
Atom Framework Resource Layout
This layout wraps the LivewireResourceAdapter component with the app's layout
--}}

<x-layouts.app title="Products">
    @livewire('adapters.livewire-resource-adapter', array_merge(compact('resource', 'page', 'record'), ['autoLayout' => false]), key('resource-' . $resource . '-' . $page))
</x-layouts.app>