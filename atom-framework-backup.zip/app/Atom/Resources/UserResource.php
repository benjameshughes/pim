<?php

namespace App\Atom\Resources;

use App\Atom\Resources\Resource;
use App\Atom\Core\Tables\Action;
use App\Atom\Core\Tables\BulkAction;
use App\Atom\Core\Tables\Column;
use App\Atom\Core\Tables\Filter;
use App\Atom\Core\Tables\HeaderAction;
use App\Atom\Core\Tables\Table;
use App\Models\User;

/**
 * User Resource
 * 
 * Resource class for managing User records across different systems.
 */
class UserResource extends Resource
{
    /**
     * The resource's associated Eloquent model.
     */
    protected static ?string $model = App\Models\User::class;
    
    /**
     * The resource navigation label.
     */
    protected static ?string $navigationLabel = 'Users';
    
    /**
     * The resource navigation icon.
     */
    protected static ?string $navigationIcon = 'cube';
    
    /**
     * The resource navigation group.
     */
    protected static ?string $navigationGroup = null;
    
    /**
     * The model label (singular).
     */
    protected static ?string $modelLabel = 'user';
    
    /**
     * The plural model label.
     */
    protected static ?string $pluralModelLabel = 'users';
    
    /**
     * The record title attribute for identification.
     */
    protected static ?string $recordTitleAttribute = 'name';
    
    /**
     * Configure the resource table.
     */
    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Column::make('id')
                    ->label('ID')
                    ->sortable(),

                Column::make('name')
                    ->label('Name')
                    ->sortable()
                    ->searchable(),

                Column::make('created_at')
                    ->label('Created')
                    ->sortable(),
            ])
            ->filters([
                // Add your filters here
            ])
            ->headerActions([
                HeaderAction::make('create')
                    ->label('Create User')
                    ->icon('plus')
                    ->color('primary'),
            ])
            ->actions([
                Action::make('edit')
                    ->label('Edit')
                    ->icon('pencil')
                    ->url(fn ($record) => static::getUrl('edit', ['record' => $record])),
                    
                Action::make('delete')
                    ->label('Delete')
                    ->icon('trash')
                    ->color('danger')
                    ->requiresConfirmation()
                    ->action(function ($record) {
                        $record->delete();
                        session()->flash('success', 'User deleted successfully.');
                    }),
            ])
            ->bulkActions([
                BulkAction::make('delete')
                    ->label('Delete Selected')
                    ->icon('trash')
                    ->color('danger')
                    ->requiresConfirmation()
                    ->action(function ($records) {
                        App\Models\User::whereIn('id', $records)->delete();
                        session()->flash('success', count($records) . ' users deleted successfully.');
                    }),
            ]);
    }
}