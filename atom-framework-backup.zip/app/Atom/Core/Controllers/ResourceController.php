<?php

namespace App\Atom\Core\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

/**
 * Resource Controller
 * 
 * Handles requests for Atom framework resources and renders them
 * as full-page Livewire components with proper layout inheritance.
 */
class ResourceController extends Controller
{
    /**
     * Handle resource page requests.
     */
    public function __invoke(Request $request)
    {
        $resource = $request->route('resource');
        $page = $request->route('page', 'index');
        $record = $request->route('record');
        
        // Render the Livewire component as a full page
        return view('atom::layouts.resource', [
            'resource' => $resource,
            'page' => $page,
            'record' => $record,
        ]);
    }
}