<?php

namespace App\Atom\Core\Support\Concerns;

use App\Atom\Core\Tables\Concerns\InteractsWithTable;
use App\Atom\Core\Tables\Table;
use App\Atom\Resources\ResourceManager;

/**
 * HasResourceTable Trait
 * 
 * Add this trait to your existing Livewire components to instantly
 * get {{ $this->table }} functionality powered by Atom framework.
 * 
 * Usage:
 * 1. Add this trait to your Livewire component
 * 2. Set public string $resource = YourResource::class
 * 3. Use {{ $this->table }} in your Blade view
 */
trait HasResourceTable
{
    use InteractsWithTable;
    
    /**
     * The resource class to use for the table.
     * Set this in your component: public string $resource = ProductResource::class;
     */
    // public string $resource;
    
    /**
     * Configure the table using the resource.
     */
    public function table(Table $table): Table
    {
        if (!isset($this->resource)) {
            throw new \Exception(
                'Property $resource must be set when using HasResourceTable trait. ' .
                'Example: public string $resource = ProductResource::class;'
            );
        }
        
        if (!ResourceManager::hasResource($this->resource)) {
            throw new \InvalidArgumentException("Resource [{$this->resource}] is not registered.");
        }
        
        $table->model($this->resource::getModel());
        return $this->resource::table($table);
    }
    
    /**
     * {{ $this->table }} - Complete resource table property
     */
    public function getTableProperty()
    {
        if (!isset($this->resource)) {
            return '<div class="p-4 text-red-500 border border-red-300 rounded">Error: $resource property not set in component</div>';
        }
        
        try {
            // Get the configured table
            $table = $this->table(new Table());
            
            // Get the data with current filters, search, pagination
            $data = $table->getData();
            
            // Render using the resource table view
            return view('atom::components.resource-table', [
                'table' => $table,
                'data' => $data,
                'resource' => $this->resource,
                'config' => ResourceManager::getResourceConfig($this->resource),
            ])->render();
            
        } catch (\Exception $e) {
            if (config('app.debug')) {
                return '<div class="p-4 text-red-500 border border-red-300 rounded">Table Error: ' . $e->getMessage() . '</div>';
            }
            return '<div class="p-4 text-red-500 border border-red-300 rounded">Table could not be loaded</div>';
        }
    }
    
    /**
     * Handle table row actions.
     */
    public function handleTableAction(string $action, mixed $recordId): void
    {
        if (!isset($this->resource)) {
            return;
        }
        
        $record = ResourceManager::resolveRecord($this->resource, $recordId);
        
        match ($action) {
            'edit' => $this->redirect($this->resource::getUrl('edit', ['record' => $record])),
            'view' => $this->redirect($this->resource::getUrl('view', ['record' => $record])),
            'delete' => $this->deleteTableRecord($record),
            default => $this->handleCustomTableAction($action, $record),
        };
    }
    
    /**
     * Handle delete action.
     */
    protected function deleteTableRecord($record): void
    {
        $recordTitle = $record->{$this->resource::getRecordTitleAttribute()} ?? "#{$record->getKey()}";
        $record->delete();
        
        session()->flash('success', "'{$recordTitle}' was deleted successfully.");
        
        // Refresh the component to show updated data
        $this->dispatch('$refresh');
    }
    
    /**
     * Handle custom table actions.
     * Override this method in your component to handle custom actions.
     */
    protected function handleCustomTableAction(string $action, $record): void
    {
        // Override this method in your component for custom actions
    }
    
    /**
     * Handle bulk table actions.
     */
    public function handleTableBulkAction(string $action, array $selectedRecords): void
    {
        if (!isset($this->resource)) {
            return;
        }
        
        match ($action) {
            'delete' => $this->bulkDeleteTableRecords($selectedRecords),
            default => $this->handleCustomBulkAction($action, $selectedRecords),
        };
    }
    
    /**
     * Handle bulk delete.
     */
    protected function bulkDeleteTableRecords(array $selectedRecords): void
    {
        $modelClass = $this->resource::getModel();
        $count = $modelClass::whereIn('id', $selectedRecords)->count();
        $modelClass::whereIn('id', $selectedRecords)->delete();
        
        session()->flash('success', "{$count} records deleted successfully.");
        
        // Clear selection and refresh
        $this->selectedTableRecords = [];
        $this->dispatch('$refresh');
    }
    
    /**
     * Handle custom bulk actions.
     * Override this method in your component to handle custom bulk actions.
     */
    protected function handleCustomBulkAction(string $action, array $selectedRecords): void
    {
        // Override this method in your component for custom bulk actions
    }
}