<?php

namespace App\Atom\Core\Adapters;

use App\Atom\Core\Tables\Concerns\InteractsWithTable;
use App\Atom\Core\Tables\Table;
use App\Atom\Resources\ResourceManager;
use Livewire\Component;
use Livewire\WithPagination;

/**
 * Resource Table Component
 * 
 * Simplified Livewire component specifically designed for drop-in usage
 * in existing Blade views. Just use @livewire('resource-table', ['resource' => App\Atom\Resources\ProductResource::class])
 * or {{ $this->table }} in your existing Livewire components.
 */
class ResourceTableComponent extends Component
{
    use InteractsWithTable, WithPagination;
    
    /**
     * The resource class to display.
     */
    public string $resource;
    
    /**
     * Component mount.
     */
    public function mount(string $resource): void
    {
        if (!ResourceManager::hasResource($resource)) {
            throw new \InvalidArgumentException("Resource [{$resource}] is not registered.");
        }
        
        $this->resource = $resource;
    }
    
    /**
     * Configure the table using the resource.
     */
    public function table(Table $table): Table
    {
        $table->model($this->resource::getModel());
        return $this->resource::table($table);
    }
    
    /**
     * Get the resource configuration.
     */
    public function getResourceConfig(): array
    {
        return ResourceManager::getResourceConfig($this->resource);
    }
    
    /**
     * Handle row actions.
     */
    public function handleAction(string $action, mixed $recordId): void
    {
        $record = ResourceManager::resolveRecord($this->resource, $recordId);
        
        match ($action) {
            'edit' => $this->redirect($this->resource::getUrl('edit', ['record' => $record])),
            'view' => $this->redirect($this->resource::getUrl('view', ['record' => $record])),
            'delete' => $this->deleteRecord($record),
            default => null,
        };
    }
    
    /**
     * Handle delete action.
     */
    protected function deleteRecord($record): void
    {
        $recordTitle = $record->{$this->resource::getRecordTitleAttribute()} ?? "#{$record->getKey()}";
        $record->delete();
        
        session()->flash('success', "'{$recordTitle}' was deleted successfully.");
        
        // Refresh the component to show updated data
        $this->dispatch('$refresh');
    }
    
    /**
     * Handle bulk actions.
     */
    public function handleBulkAction(string $action, array $selectedRecords): void
    {
        match ($action) {
            'delete' => $this->bulkDelete($selectedRecords),
            default => null,
        };
    }
    
    /**
     * Handle bulk delete.
     */
    protected function bulkDelete(array $selectedRecords): void
    {
        $modelClass = $this->resource::getModel();
        $count = $modelClass::whereIn('id', $selectedRecords)->count();
        $modelClass::whereIn('id', $selectedRecords)->delete();
        
        session()->flash('success', "{$count} records deleted successfully.");
        
        // Clear selection and refresh
        $this->selectedTableRecords = [];
        $this->dispatch('$refresh');
    }
    
    /**
     * Render the component with a minimal view.
     */
    public function render()
    {
        $table = $this->table(new Table());
        $data = $table->getData();
        
        return view('atom::components.resource-table', [
            'table' => $table,
            'data' => $data,
            'resource' => $this->resource,
            'config' => $this->getResourceConfig(),
        ]);
    }
}